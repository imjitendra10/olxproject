package com.training.olxadvertises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlxAdevrtisesApplicationTests {

	@Test
	void contextLoads() {
	}

}
